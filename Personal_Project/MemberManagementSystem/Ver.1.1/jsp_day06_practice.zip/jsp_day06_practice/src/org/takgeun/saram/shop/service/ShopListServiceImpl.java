package org.takgeun.saram.shop.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.ShopDto;
import org.takgeun.saram.controller.Service;


public class ShopListServiceImpl implements Service {
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<ShopDto> productList = (ArrayList<ShopDto>)shopDao.selectAll();
		req.setAttribute("productList", productList);
	}

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		try {
			doGet(req, resp);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
		return new ModelAndView("shop/list", false);
	}

}
