package org.takgeun.board.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.BoardDto;
import org.takgeun.saram.controller.Service;

public class BoardModifyServiceImpl implements Service {
	// 처음에 겟 방식으로 진입
	// 수정할 때에는 포스트 방식으로 진입할 것.
	// request.setAttribute("modifyByNum", boardDto.getBoard_num());
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		// 겟방식 진입 시에는 dto를 뷰에다가 반환해야한다.
		
		System.out.println(req.getParameter("no"));
		BoardDto boardDto = boardDao.selectByNum(req.getParameter("no"));
		
		req.setAttribute("boardDto", boardDto);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		int board_num = Integer.parseInt(req.getParameter("board_num"));
		String board_name = req.getParameter("board_name");
		String board_pass = req.getParameter("board_pass");
		String board_subject = req.getParameter("board_subject");
		String board_content = req.getParameter("board_content");

		BoardDto boardDto = new BoardDto(board_num, board_name, board_pass, board_subject, board_content, 0, "");
		
		boardDao.update(boardDto);
	}
	
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		ModelAndView mav = new ModelAndView("list.saram", true);
		
		if("GET".equals(req.getMethod())) {
			doGet(req, resp);
			mav = new ModelAndView("bbs/board_modify");
		} else
			try {
				doPost(req, resp);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return mav;
	}

}
