package org.takgeun.saram.controller;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.board.service.BoardDeleteServiceImpl;
import org.takgeun.board.service.BoardDetailServiceImpl;
import org.takgeun.board.service.BoardInputServiceImpl;
import org.takgeun.board.service.BoardListServiceImpl;
import org.takgeun.board.service.BoardModifyServiceImpl;
import org.takgeun.controller.ModelAndView;

public class BoardController implements Controller{

	Service service;
	Hashtable<String, Service> mapping = new Hashtable<String, Service>();
	{
		mapping.put("/list", new BoardListServiceImpl());
		mapping.put("/input", new BoardInputServiceImpl());
		mapping.put("/modify", new BoardModifyServiceImpl());
		mapping.put("/delete", new BoardDeleteServiceImpl());
		mapping.put("/detail", new BoardDetailServiceImpl());
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		String key = (String)req.getAttribute("serviceKey");
		// /list
		service = mapping.get(key);
		
		return service.request(req, resp);
	}

}
