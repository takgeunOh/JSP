package org.takgeun.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.takgeun.saram.dbcp.JdbcUtil;

public class BoardDao {
	final String SQL_INSERT = "insert into board values(board_seq.nextval, ?, ?, ?, ?, ?, sysdate)";
	final String SQL_SELECT_ALL = "SELECT * FROM board ORDER BY BOARD_NUM DESC";
	final String SQL_SELECT_NUM = "SELECT * FROM board WHERE BOARD_NUM=?";
	final String SQL_SELECT_SUBJECT = "SELECT * FROM board WHERE BOARD_SUBJECT=?";
	final String SQL_UPDATE = "UPDATE board SET BOARD_NAME=?, BOARD_PASS=?, BOARD_SUBJECT=?, BOARD_CONTENT=? WHERE BOARD_NUM=?";
	final String SQL_UPDATE_READCOUNT = "update board set board_readcount=? where board_num=?";
	final String SQL_DELETE = "DELETE FROM board WHERE BOARD_NUM=?";

	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;

	public void insert(BoardDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_INSERT);
			stmt.setString(1, dto.getBoard_name());
			stmt.setString(2, dto.getBoard_pass());
			stmt.setString(3, dto.getBoard_subject());
			stmt.setString(4, dto.getBoard_content());
			stmt.setInt(5, 0);				// 조회수
			
			int cnt = stmt.executeUpdate();
			
			if (cnt > 0) {
				conn.commit();
			} else {
				conn.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
	}

	public List<BoardDto> selectAll() {
		ArrayList<BoardDto> list = new ArrayList<BoardDto>();
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_ALL);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int board_num = rs.getInt("board_num");
				String board_name = rs.getString("board_name");
				String board_pass = rs.getString("board_pass");
				String board_subject = rs.getString("board_subject");
				String board_content = rs.getString("board_content");
				int board_readcount = rs.getInt("board_readcount");
				String board_date = rs.getString("board_date");
				
				list.add(new BoardDto(board_num, board_name, board_pass, board_subject, board_content, board_readcount, board_date));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
		
		JdbcUtil.close(conn, stmt, rs);
		
		return list;
	}
	
	public BoardDto selectByNum(String numStr) {
		System.out.println("BoardDao numStr " + numStr);
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_NUM);
			stmt.setInt(1, Integer.parseInt(numStr));
			rs = stmt.executeQuery();		// resultSet
			
			if(rs.next()) {
				int board_num = rs.getInt("board_num");
				String board_name = rs.getString("board_name");
				String board_pass = rs.getString("board_pass");
				String board_subject = rs.getString("board_subject");
				String board_content = rs.getString("board_content");
				int board_readcount = rs.getInt("board_readcount");			// 추후 업데이트 메서드를 통해서 올려보자.
				String board_date = rs.getString("board_date");
				
				BoardDto boardDto = new BoardDto(board_num, board_name, board_pass, board_subject, board_content, board_readcount, board_date);
				
				return boardDto;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	public void update(BoardDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt=conn.prepareStatement(SQL_UPDATE);
			stmt.setString(1, dto.getBoard_name());
			stmt.setString(2, dto.getBoard_pass());
			stmt.setString(3, dto.getBoard_subject());
			stmt.setString(4, dto.getBoard_content());
			stmt.setInt(5, dto.getBoard_num());
			
			int cnt = stmt.executeUpdate();
			
			if(cnt>0)
				conn.commit();
			else
				conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}
	
	public int ExtractReadCount(int num) {
		// 먼저 번호로 찾고
		// 해당 번호의 조회수를 추출한 다음
		// 그 번호인 애한테 추출한 조회수 + 1 해주기
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_NUM);
			stmt.setInt(1, num);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				int saveReadCount = rs.getInt("board_readcount");
				return saveReadCount;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
		
		return 0;
	}
	
	public void readCountUpdate(int saveReadCount, int num) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_UPDATE_READCOUNT);
			stmt.setInt(1, saveReadCount+1);
			stmt.setInt(2, num);
			int cnt = stmt.executeUpdate();
			
			if(cnt>0)
				conn.commit();
			else
				conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}
	
	public void delete(int num) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_DELETE);
			stmt.setInt(1, num);
			int cnt=stmt.executeUpdate();
			
			if(cnt>0)
				conn.commit();
			else
				conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}
}
