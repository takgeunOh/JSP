package org.takgeun.saram.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.controller.ViewResolver;
import org.takgeun.model.BoardDao;
import org.takgeun.model.MemberDao;
import org.takgeun.model.SaramDao;
import org.takgeun.model.ShopDao;

public interface Controller {
	BoardDao boardDao = new BoardDao();
	ShopDao shopDao = new ShopDao();
	MemberDao memberDao = new MemberDao();
	SaramDao saramDao = new SaramDao();
	ViewResolver viewResolver = new ViewResolver();
	ModelAndView request(HttpServletRequest req, HttpServletResponse resp);
}
