package org.takgeun.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ViewResolver {
	private String prifix = "/WEB-INF/views/";
	private String suffix = ".jsp";
	private String viewName = "/WEB-INF/views/saram_list.jsp";

	public String getPrifix() {
		return prifix;
	}

	public void setPrifix(String prifix) {
		this.prifix = prifix;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public void forward(String viewName, HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.viewName = viewName;
		RequestDispatcher view = req.getRequestDispatcher(this.viewName);
		view.forward(req, resp);
	}

	public void forward(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if (viewName.indexOf("redirect:") != -1) {
			viewName = viewName.substring(viewName.indexOf(":") + 1);
			resp.sendRedirect(viewName);
			return;
		}

		RequestDispatcher view = req.getRequestDispatcher(this.viewName);
		view.forward(req, resp);
	}

	public void forward(HttpServletRequest req, HttpServletResponse resp, ModelAndView modelAndView) {
		boolean isRedirect = modelAndView.isRedirect();		// false
		viewName = modelAndView.getViewName();				// "/WEB-INF/views/saram_list.jsp";
		try {
			if (isRedirect) {
				resp.sendRedirect(viewName);
			} else {
				RequestDispatcher view = req.getRequestDispatcher(prifix+ viewName +suffix);			// prefix + member/login + suffix
				view.forward(req, resp);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		}
	}
}
