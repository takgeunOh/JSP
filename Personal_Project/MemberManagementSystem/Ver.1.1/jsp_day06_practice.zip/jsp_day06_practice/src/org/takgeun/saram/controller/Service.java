package org.takgeun.saram.controller;

public interface Service extends Controller {

}
