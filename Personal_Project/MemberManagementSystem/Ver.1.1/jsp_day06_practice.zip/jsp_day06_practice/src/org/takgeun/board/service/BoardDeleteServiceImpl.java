package org.takgeun.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.saram.controller.Service;

public class BoardDeleteServiceImpl implements Service {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		
		// System.out.println(" BoardDeleteService num " + req.getParameter("no"));			// 정상 출력
		boardDao.delete(Integer.parseInt(req.getParameter("no")));
		
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		ModelAndView mav = new ModelAndView("list.saram", true);
		doGet(req, resp);
		
		return mav;
	}

}
