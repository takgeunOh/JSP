package org.takgeun.home.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.SaramDto;
import org.takgeun.saram.controller.Service;

public class ListServiceImpl implements Service {
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<SaramDto> saramList = (ArrayList<SaramDto>)saramDao.selectAll();
		req.setAttribute("saramList", saramList);
	}

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		try {
			doGet(req, resp);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
		return new ModelAndView("home/saram_list", false);
	}
}
