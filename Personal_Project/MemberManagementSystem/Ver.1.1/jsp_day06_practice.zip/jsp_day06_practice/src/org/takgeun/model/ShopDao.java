package org.takgeun.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class ShopDao {
	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;

	static List<ShopDto> list = new ArrayList<ShopDto>();
	static {
		list.add(new ShopDto(10, "냉장고", 400, "LG", 0));
		list.add(new ShopDto(11, "세탁기", 200, "SAMSUNG", 0));
		list.add(new ShopDto(21, "청소기", 120, "다이슨", 0));
		list.add(new ShopDto(32, "테레비", 300, "노브랜드", 0));
		list.add(new ShopDto(44, "핸드폰", 120, "애플", 0));
		list.add(new ShopDto(55, "건조기", 70, "LG", 0));
		list.add(new ShopDto(61, "레인지", 50, "LG", 0));
		list.add(new ShopDto(71, "에어콘", 200, "위니아", 0));
		list.add(new ShopDto(81, "리모콘", 10, "LG", 0));
		list.add(new ShopDto(90, "선풍기", 40, "신일", 0));
	}

	public void insert(ShopDto dto) {

	}

	public List<ShopDto> selectAll() {

		return list;
	}

	public void update(ShopDto dto) {

	}

	public void delete(ShopDto dto) {

	}

	public ShopDto selectByName(ShopDto dto) {

		return null;
	}

	public ShopDto selectByNo(ShopDto dto) {
		int idx = list.indexOf(dto);
		if(idx != -1 ) {
			return list.get(idx);
		}
		return null;
	}

	public ShopDto selectByNo(int no) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getNo() == no) {
				return list.get(i);
			}
		}
		return null;
	}
}
