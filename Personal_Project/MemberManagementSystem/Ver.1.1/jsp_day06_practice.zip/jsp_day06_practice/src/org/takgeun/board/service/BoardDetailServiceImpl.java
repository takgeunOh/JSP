package org.takgeun.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.BoardDto;
import org.takgeun.saram.controller.Service;

public class BoardDetailServiceImpl implements Service {

	// get 방식으로 들어올 것
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		String numStr = req.getParameter("num");
		System.out.println("BoardDetailServiceImpl numStr : " + numStr);			// 정상 출력
		
		// 클릭을 하면 글 내용이 보이도록 할 것.
		// num에 맞는 dto를 반환 받아서
		// request에 저장할 것.
		BoardDto boardDto = new BoardDto();
		boardDto = boardDao.selectByNum(numStr);
		boardDao.readCountUpdate(boardDao.ExtractReadCount(Integer.parseInt(numStr)), Integer.parseInt(numStr));
		
		req.setAttribute("boardDto", boardDto);
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {

		doGet(req, resp);
		
		return new ModelAndView("bbs/board_detail", false);
	}

}
