package org.takgeun.home.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.SaramDto;
import org.takgeun.saram.controller.Service;

public class DetailServiceImpl implements Service {
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String noStr = req.getParameter("no");
		System.out.println("no => " + noStr);
		
		// dao에서 검색
		SaramDto saramDto = saramDao.selectByNo(Integer.parseInt(noStr));
		req.setAttribute("saramDto", saramDto);
	}

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		ModelAndView modelAndView = new ModelAndView("list.saram", true);
		if("GET".equals(req.getMethod())) {
			try {
				doGet(req, resp);
			} catch (ServletException | IOException e) {
				e.printStackTrace();
			}
			modelAndView = new ModelAndView("home/saram_detail");
		}
		return modelAndView;
	}
}
