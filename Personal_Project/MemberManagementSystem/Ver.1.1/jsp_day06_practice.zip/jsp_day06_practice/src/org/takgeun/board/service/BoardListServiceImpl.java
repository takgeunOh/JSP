package org.takgeun.board.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.BoardDto;
import org.takgeun.saram.controller.Service;

public class BoardListServiceImpl implements Service {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		ArrayList<BoardDto> boardList = (ArrayList<BoardDto>) boardDao.selectAll();
		req.setAttribute("boardList", boardList);
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		doGet(req, resp);
		
		return new ModelAndView("bbs/board_list", false);
	}

}
