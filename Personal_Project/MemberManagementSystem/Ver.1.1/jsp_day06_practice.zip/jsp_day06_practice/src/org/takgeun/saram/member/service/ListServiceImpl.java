package org.takgeun.saram.member.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.MemberDto;
import org.takgeun.saram.controller.Service;

public class ListServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		if(req.getMethod().equals("GET")) {
			// dao 호출 후 갱신 된다.
			ArrayList<MemberDto> list = (ArrayList<MemberDto>)memberDao.selectAll();
			req.setAttribute("list", list);
			return new ModelAndView("member/list");
		} else if(req.getMethod().equals("POST")) {
			
			return new ModelAndView(req.getContextPath()+"/", true);
		}
		return null;
	}

}
