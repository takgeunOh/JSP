package org.takgeun.saram.shop.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.ShopDto;
import org.takgeun.saram.controller.Service;

public class ProductDetailServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		int no = Integer.parseInt(req.getParameter("no"));
		System.out.println("ProductDetailServiceImpl");
		
		ShopDto shopDto = shopDao.selectByNo(no);
		System.out.println(shopDto);
		req.setAttribute("shopDto", shopDto);
		
		return new ModelAndView("shop/detail", false);
	}

}
