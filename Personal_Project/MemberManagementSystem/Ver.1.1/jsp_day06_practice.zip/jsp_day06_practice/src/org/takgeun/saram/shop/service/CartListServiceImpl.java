package org.takgeun.saram.shop.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.ShopDto;
import org.takgeun.saram.controller.Service;

public class CartListServiceImpl implements Service {
	private HttpSession session;

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		session = req.getSession();
		
		if("GET".equals(req.getMethod())) {
			System.out.println("GET >>>>>> ");
			System.out.println("카트 목록 보기");
		} else if("POST".equals(req.getMethod())) {
			System.out.println("POST >>>>>> ");
			int no = req.getParameter("no")!=null ? Integer.parseInt(req.getParameter("no")): -1;
			ShopDto dto = shopDao.selectByNo(no);
			ArrayList<ShopDto> cartList = null;
			if(session.getAttribute("cartList") == null) {
				// 최초로 만든 cartList
				cartList = new ArrayList<ShopDto>();
				session.setAttribute("cartList", cartList);
			} else {
				cartList = (ArrayList<ShopDto>)session.getAttribute("cartList");
			}
			cartList.add(dto);
			System.out.println("======> no : " + no);
			System.out.println("카트에 추가하기");
		} else if("DELETE".equals(req.getMethod())) {
			System.out.println("DELETE >>>>>> ");
			System.out.println("삭제");
		} else if("PUT".equals(req.getMethod())) {
			System.out.println("PUT >>>>>> ");
			System.out.println("수정");
		}
		return new ModelAndView("shop/cart", false);
	}

}
