package org.takgeun.saram.controller;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.saram.shop.service.CartListServiceImpl;
import org.takgeun.saram.shop.service.ProductDetailServiceImpl;
import org.takgeun.saram.shop.service.ShopListServiceImpl;

public class ShopController implements Controller {
	Service service;
	Hashtable<String, Service> mapping = new Hashtable<String, Service>();
	{
		mapping.put("/cart", new CartListServiceImpl());
		mapping.put("/detail", new ProductDetailServiceImpl());
		mapping.put("/list", new ShopListServiceImpl());
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		String serviceKey = (String)req.getAttribute("serviceKey");
		System.out.println(serviceKey);
		service = mapping.get(serviceKey);
		return service.request(req, resp);
	}

}
