package org.takgeun.saram.member.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.takgeun.controller.ModelAndView;
import org.takgeun.saram.controller.Service;

public class LoginServiceImpl implements Service {
	ModelAndView mav;
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		if(req.getMethod().equals("GET")) {
			mav = new ModelAndView("member/login");
		} else if(req.getMethod().equals("POST")) {
			HttpSession session = req.getSession();
			String userId = req.getParameter("userId");
			String userPwd = req.getParameter("userPwd");
			
			if("admin".equals(userId) && "12345".equals(userPwd)) {
				System.out.println(">>> ID와 PASSWORD가 일치 합니다!");
				session.setAttribute("user.id", userId);
				session.setAttribute("user.name", "일지매");
			}
			mav = new ModelAndView(req.getContextPath()+"/member/login.saram", true);
		}
		return mav;
	}
}
