package org.takgeun.model;

public class BoardDto {
	private int board_num, board_readcount;
	private String board_name, board_pass, board_subject, board_content, board_date;
	
	public BoardDto() {
		this(0, "", "", "", "", 0, "");
	}
	
	public BoardDto(String board_name, String board_pass, String board_subject, String board_content) {
		this.board_name = board_name;
		this.board_pass = board_pass;
		this.board_subject = board_subject;
		this.board_content = board_content;
		this.board_readcount = 0;
	}
	
	public BoardDto(int board_num, String board_name, String board_pass, String board_subject, String board_content, int board_readcount, String board_date) {
		this.board_num = board_num;
		this.board_name = board_name;
		this.board_pass = board_pass;
		this.board_subject = board_subject;
		this.board_content = board_content;
		this.board_readcount = board_readcount;
		this.board_date = board_date;
	}
	
	
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public int getBoard_readcount() {
		return board_readcount;
	}
	public void setBoard_readcount(int board_readcount) {
		this.board_readcount = board_readcount;
	}
	public String getBoard_name() {
		return board_name;
	}
	public void setBoard_name(String board_name) {
		this.board_name = board_name;
	}
	public String getBoard_pass() {
		return board_pass;
	}
	public void setBoard_pass(String board_pass) {
		this.board_pass = board_pass;
	}
	public String getBoard_subject() {
		return board_subject;
	}
	public void setBoard_subject(String board_subject) {
		this.board_subject = board_subject;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public String getBoard_date() {
		return board_date;
	}
	public void setBoard_date(String board_date) {
		this.board_date = board_date;
	}
	@Override
	public String toString() {
		return "BoardDto [board_num=" + board_num + ", board_readCount=" + board_readcount + ", board_name="
				+ board_name + ", board_pass=" + board_pass + ", board_subject=" + board_subject + ", board_content="
				+ board_content + ", board_date=" + board_date + "]";
	}
	
	
}
