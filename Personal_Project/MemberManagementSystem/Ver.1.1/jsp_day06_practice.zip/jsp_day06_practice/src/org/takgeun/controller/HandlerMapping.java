package org.takgeun.controller;

import java.util.Hashtable;

import org.takgeun.saram.controller.BoardController;
import org.takgeun.saram.controller.Controller;
import org.takgeun.saram.controller.HomeController;
import org.takgeun.saram.controller.ShopController;

public class HandlerMapping {
	Hashtable<String, Controller> map = new Hashtable<String, Controller>();
	{
		map.put("/home", new HomeController());
		map.put("/bbs", new BoardController());
		map.put("/shop", new ShopController());
		map.put("/member", new MemberController());
	}
	
	public Controller getController(String path) {
		return map.get(path);
	}
}
