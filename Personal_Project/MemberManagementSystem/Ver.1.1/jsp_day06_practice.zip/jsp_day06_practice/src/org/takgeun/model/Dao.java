package org.takgeun.model;

import java.util.List;

public interface Dao {

	void insert(SaramDto dto);

	List<SaramDto> selectAll();

	void update(SaramDto dto);

	void delete(SaramDto dto);

	SaramDto selectByName(SaramDto dto);

	SaramDto selectByNo(SaramDto dto);

	SaramDto selectByNo(int no);

}