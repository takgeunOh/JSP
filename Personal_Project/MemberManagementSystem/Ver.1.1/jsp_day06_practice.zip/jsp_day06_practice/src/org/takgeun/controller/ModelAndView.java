package org.takgeun.controller;

public class ModelAndView {
	private String viewName = "list";
	private boolean isRedirect = false;
	
	public void setRedirect(boolean isRedirect) {
		this.isRedirect = isRedirect;
	}
	public ModelAndView() {
		this("/list", false);
	}
	public ModelAndView(String viewName) {
		this(viewName, false);
	}
	public ModelAndView(String viewName, boolean isRedirect) {
		this.viewName = viewName;
		this.isRedirect = isRedirect;
	}
	
	public String getViewName() {
		return viewName;
	}

	public void setViewName(String viewName) {
		this.viewName = viewName;
	}

	public boolean isRedirect() {
		return isRedirect;
	}
}
