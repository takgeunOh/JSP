package org.takgeun.board.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.controller.ModelAndView;
import org.takgeun.model.BoardDto;
import org.takgeun.saram.controller.Service;

public class BoardInputServiceImpl implements Service {

	// 처음엔 겟방식으로 들어오고
	// 이후에 입력 받고나서는 포스트 방식으로
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		// 여기서는 할 게 없다. 단순히 mav 에서 뷰 경로만 반환할 것이니깐
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws UnsupportedEncodingException {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		// POST 방식으로 받아올 때 인코딩 반드시 해줄 것.
		
		String board_name = req.getParameter("board_name");
		String board_pass = req.getParameter("board_pass");
		String board_subject = req.getParameter("board_subject");
		String board_content = req.getParameter("board_content");
		
		BoardDto boardDto = new BoardDto(board_name, board_pass, board_subject, board_content);
		
		boardDao.insert(boardDto);
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		ModelAndView modelAndView = new ModelAndView("list.saram", true);
		
		if("GET".equals(req.getMethod())) {
			doGet(req, resp);
			modelAndView = new ModelAndView("bbs/board_input");	// 리다이렉트는 안함
		} else {
			try {
				doPost(req, resp);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return modelAndView;
	}

}
