package org.takgeun.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.saram.controller.Controller;

public class DispatcherServlet extends HttpServlet{
	// path 만들어서 이 path를 핸들러맵핑에서 써먹고 적절한 컨트롤러 반환받기
	private HandlerMapping handlerMapping = new HandlerMapping();
	private ViewResolver viewResolver = new ViewResolver();
	private void process(HttpServletRequest req, HttpServletResponse resp) {
		System.out.println("Dispatcher method : " + req.getMethod());
		// GET
		String ctxPath = req.getContextPath();
		String uri = req.getRequestURI();
		int startIndex = ctxPath.length();
		int endIndex = uri.indexOf(".");
		
		String path = uri.substring(startIndex, endIndex);
		System.out.println("Dispatcher path : " + path);
		// /bbs/list
		
		String prepath = path.substring(0, path.indexOf("/", 1));
		System.out.println("Dispatcher prepath : " + prepath);
		// /bbs
		
		Controller controller = handlerMapping.getController(prepath);
		
		req.setAttribute("serviceKey", path.substring(path.indexOf("/", 1)));
		System.out.println("Dispatcher serviceKey : " + path.substring(path.indexOf("/", 1)));
		// /list
		// /input
		// /detail
		// /modify

		
		if(controller!=null) {
			ModelAndView modelAndView = controller.request(req, resp);
			System.out.println("DispatcherServlet mav 확인 : " + modelAndView);
			if(modelAndView != null) {
				viewResolver.forward(req, resp, modelAndView);
				// bbs/board_list , false
			} else
				System.out.println(">>> modelAndView가 null 입니다.");
		} else
			System.out.println(">>> controller가 null 입니다.");
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
}
