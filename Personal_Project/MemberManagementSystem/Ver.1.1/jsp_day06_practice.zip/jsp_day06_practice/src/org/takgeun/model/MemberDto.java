package org.takgeun.model;
/*
no number primary key,
id varchar2(30) not null,
password varchar(50) not null,
name varchar2(20),
email varchar2(50)
 */
public class MemberDto {
	private int no;
	private String id;
	private String password;
	private String name;
	private String email;
	
	public MemberDto() {
		this(0, "","","","");
	}

	public MemberDto(int no, String id, String password, String name, String email) {
		this.no = no;
		this.id = id;
		this.password = password;
		this.name = name;
		this.email = email;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "["+ no +", "+ id +", "+ password +", "+ name +", "+ email +"]";
	}
}
