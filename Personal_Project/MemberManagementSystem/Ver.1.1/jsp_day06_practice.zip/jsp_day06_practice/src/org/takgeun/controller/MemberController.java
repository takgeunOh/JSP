package org.takgeun.controller;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.takgeun.saram.controller.Controller;
import org.takgeun.saram.controller.Service;
import org.takgeun.saram.member.service.DetailServiceImpl;
import org.takgeun.saram.member.service.FindIDServiceImpl;
import org.takgeun.saram.member.service.JoinServiceImpl;
import org.takgeun.saram.member.service.ListServiceImpl;
import org.takgeun.saram.member.service.LoginServiceImpl;
import org.takgeun.saram.member.service.LogoutServiceImpl;
import org.takgeun.saram.member.service.ModifyServiceImpl;


public class MemberController implements Controller {
	Service service;
	Hashtable<String, Service> map = new Hashtable<String, Service>();
	{
		map.put("/join", new JoinServiceImpl());
		map.put("/list", new ListServiceImpl());
		map.put("/login", new LoginServiceImpl());
		map.put("/logout", new LogoutServiceImpl());
		map.put("/detail", new DetailServiceImpl());
		map.put("/findid", new FindIDServiceImpl());
		map.put("/modify", new ModifyServiceImpl());
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		service = map.get(req.getAttribute("serviceKey"));
		return service.request(req, resp);
	}
}
