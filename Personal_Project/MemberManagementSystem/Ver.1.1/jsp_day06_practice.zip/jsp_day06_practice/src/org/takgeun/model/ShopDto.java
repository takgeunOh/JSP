package org.takgeun.model;

public class ShopDto {
	private int no;
	private String title;
	private int price;
	private String maker;
	private int ea;
	
	public ShopDto() {
		this(0,"",0,"",0);
	}
	public ShopDto(int no, String title, int price, String maker, int ea) {
		this.no = no;
		this.title = title;
		this.price = price;
		this.maker = maker;
		this.ea = ea;
	}
	// Lombok(롬복)
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public int getEa() {
		return ea;
	}
	public void setEa(int ea) {
		this.ea = ea;
	}
	
	@Override
	public String toString() {
		return "ShopDto [no=" + no + ", title=" + title + ", price=" + price + ", maker=" + maker + ", ea=" + ea + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + no;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ShopDto other = (ShopDto) obj;
		if (no != other.no)
			return false;
		return true;
	}
}
