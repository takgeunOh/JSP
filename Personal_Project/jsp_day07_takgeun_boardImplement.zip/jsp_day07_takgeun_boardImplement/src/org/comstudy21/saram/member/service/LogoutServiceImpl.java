package org.comstudy21.saram.member.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;

public class LogoutServiceImpl implements Service {
	ModelAndView mav;
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		if(req.getMethod().equals("GET")) {
			HttpSession session = req.getSession();
			session.invalidate(); // 세션 로그아웃
			mav = new ModelAndView(req.getContextPath() + "/", true);
		} else if(req.getMethod().equals("POST")) {
			mav = new ModelAndView("/", true);
		}
		return mav;
	}

}
