package org.comstudy21.saram.member.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.MemberDto;

public class JoinServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		try {
			req.setCharacterEncoding("UTF-8");
			resp.setCharacterEncoding("UTF-8");
			resp.setContentType("text/html; charset=UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		if(req.getMethod().equals("GET")) {
			return new ModelAndView("member/join");
		} else if(req.getMethod().equals("POST")) {
			// dao 호출 후 갱신 된다.
			String id = req.getParameter("id");
			String password = req.getParameter("password");
			String name = req.getParameter("name");
			String email = req.getParameter("email");
			MemberDto dto = new MemberDto(0, id, password, name, email);
			memberDao.insert(dto);
			return new ModelAndView(req.getContextPath() + "/", true);
		}
		return null;
	}

}
