package org.comstudy21.saram.member.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.MemberDto;

public class ListServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		if(req.getMethod().equals("GET")) {
			// dao 호출 후 갱신 된다.
			ArrayList<MemberDto> list = (ArrayList<MemberDto>)memberDao.selectAll();
			req.setAttribute("list", list);
			return new ModelAndView("member/list");
		} else if(req.getMethod().equals("POST")) {
			
			return new ModelAndView(req.getContextPath()+"/", true);
		}
		return null;
	}

}
