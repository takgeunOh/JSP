package org.comstudy21.saram.board.service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.BoardDto;

public class BoardSearchServiceImpl implements Service {

	// POST 방식으로 진입
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		try {
			req.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		ArrayList<BoardDto> list = new ArrayList<BoardDto>();
		String searchData = req.getParameter("searchText");
		System.out.println(" >> BoardSearchServiceImpl searchData : " + searchData);
		
		list = boardDao.search(searchData);
		
		req.setAttribute("searchList", list);

		return new ModelAndView("/bbs/search", false);
	}

}
