package org.comstudy21.saram.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.BoardDto;

public class BoardDeleteServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		// get 방식으로 돌아갈 것.
		
		int delNum = Integer.parseInt(req.getParameter("no"));
		System.out.println("BoardDeleteServiceImpl num : " + delNum);				// 정상 출력
		
		BoardDto boardDto = boardDao.selectOne(delNum);
		
		boardDao.delete(boardDto);
		
		return new ModelAndView("bbs/delete", false);
	}

}
