package org.comstudy21.saram.board.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.BoardDto;

public class BoardUpdateServiceImpl implements Service {
	
	// 업데이트도 처음엔 get방식으로 진입 후
	// 정보 입력 후 post 방식으로 진입
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		if("GET".equals(req.getMethod())) {
			// 겟 방식 진입 시 bbs의 update.jsp로 이동하기
			int num = (Integer.parseInt(req.getParameter("no")));
			System.out.println("BoardUpdateServiceImpl num : " + num);				// 정상 출력
			
			req.setAttribute("modifyNum", num);
			
			return new ModelAndView("bbs/update", false);
		} else {
			
			// 입력데이터를 가지고 post 방식 진입 시 처리하기
			HttpSession session = req.getSession();
			try {
				req.setCharacterEncoding("UTF-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			resp.setCharacterEncoding("UTF-8");
			resp.setContentType("text/html; charset=UTF-8");
			
			String modifyTitle = req.getParameter("modifyTitle");
			String modifyContent = req.getParameter("modifyContent");
			int modifyNum = (Integer)session.getAttribute("updateNum");					// 세션을 받아와야한다. 그 외 방법은 에이젝스도 있음.
			System.out.println("BoardUpdateServiceImpl title, content : " + modifyTitle + ", " + modifyContent);	// 정상 출력 확인
			System.out.println("BoardUpdateServiceImpl num : " + modifyNum);				// 정상 출력 확인
			
			boardDao.update(modifyTitle, modifyContent, modifyNum);
			
			return new ModelAndView("list.saram", true);
		}
		

	}

}
