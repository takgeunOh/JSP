package org.comstudy21.saram.board.service;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.BoardDto;

public class BoardInsertServiceImpl implements Service {
	
	// insert에서는 처음엔 get 방식으로 들어와서 insert.jsp 보여주고
	// insert.jsp에서 폼으로 입력을 받으면 post로 넘겨줘서 list.jsp가 리다이렉트되어서 보이도록 할 것.
	
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		try {
			req.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		// POST 방식으로 받아올 때 인코딩 반드시 해줄 것.
		
		if("GET".equals(req.getMethod())) {
			// get 방식으로 들어오면 insert.jsp로 이동
			return new ModelAndView("bbs/insert", false);
		} else {
			// post 방식으로 들어오면 기능 반영 후 목록으로 리다이렉트
			String author = req.getParameter("author");
			String email = req.getParameter("email");
			String title = req.getParameter("title");
			String content = req.getParameter("content");
			String password = req.getParameter("password");
			
			BoardDto boardDto = new BoardDto(author, email, title, content, password);
			boardDao.insert(boardDto);
			
			return new ModelAndView("list.saram", true);
		}
	}

}
