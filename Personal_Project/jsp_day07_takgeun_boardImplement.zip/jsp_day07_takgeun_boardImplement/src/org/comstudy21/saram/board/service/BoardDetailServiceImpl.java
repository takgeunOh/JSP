package org.comstudy21.saram.board.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.BoardDto;

public class BoardDetailServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		// num 값이 넘어왔으니까 num으로 셀렉트하고 그 dto를 구해서 보여주면 되겠다.
		System.out.println("list.jsp에서 디테일 서비스로 넘어온 num 값 : " + req.getParameter("num"));		// 정상 출력
		BoardDto boardDto = boardDao.selectOne(Integer.parseInt(req.getParameter("num")));
		System.out.println("BoardDetailServiceImpl boardDto : " + boardDto);
		
		String numStr = req.getParameter("num");
		boardDao.readCountUpdate(boardDao.ExtractReadCount(Integer.parseInt(numStr)), Integer.parseInt(numStr));
		
		
		req.setAttribute("boardDetailDto", boardDto);
		
		return new ModelAndView("bbs/detail", false);		// 리다이렉트 할 필요 없지.. 조회엔
	}

}
