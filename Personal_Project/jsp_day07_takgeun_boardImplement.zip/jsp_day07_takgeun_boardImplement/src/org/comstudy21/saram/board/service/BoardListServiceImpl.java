package org.comstudy21.saram.board.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.BoardDto;

public class BoardListServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		ArrayList<BoardDto> board_list = (ArrayList<BoardDto>)boardDao.selectAll();
		req.setAttribute("board_list", board_list);
		
		return new ModelAndView("bbs/list", false);
	}
}
