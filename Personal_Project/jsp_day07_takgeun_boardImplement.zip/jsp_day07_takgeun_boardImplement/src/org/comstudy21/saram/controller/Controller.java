package org.comstudy21.saram.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.controller.ViewResolver;
import org.comstudy21.saram.model.BoardDao;
import org.comstudy21.saram.model.Dao;
import org.comstudy21.saram.model.MemberDao;
import org.comstudy21.saram.model.SaramDao;
import org.comstudy21.saram.model.ShopDao;

public interface Controller {
	BoardDao boardDao = new BoardDao();
	ShopDao shopDao = new ShopDao();
	MemberDao memberDao = new MemberDao();
	SaramDao saramDao = new SaramDao();
	ViewResolver viewResolver = new ViewResolver();
	ModelAndView request(HttpServletRequest req, HttpServletResponse resp);
}
