package org.comstudy21.saram.controller;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.shop.service.CartListServiceImpl;
import org.comstudy21.saram.shop.service.ProductDetailServiceImpl;
import org.comstudy21.saram.shop.service.ShopListServiceImpl;

public class ShopController implements Controller {
	Service service;
	Hashtable<String, Service> mapping = new Hashtable<String, Service>();
	{
		mapping.put("/cart", new CartListServiceImpl());
		mapping.put("/detail", new ProductDetailServiceImpl());
		mapping.put("/list", new ShopListServiceImpl());
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		String serviceKey = (String)req.getAttribute("serviceKey");
		System.out.println(serviceKey);
		service = mapping.get(serviceKey);
		return service.request(req, resp);
	}

}
