package org.comstudy21.saram.controller;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.member.service.ListServiceImpl;
import org.comstudy21.saram.member.service.ModifyServiceImpl;
import org.comstudy21.saram.member.service.DetailServiceImpl;
import org.comstudy21.saram.member.service.FindIDServiceImpl;
import org.comstudy21.saram.member.service.JoinServiceImpl;
import org.comstudy21.saram.member.service.LoginServiceImpl;
import org.comstudy21.saram.member.service.LogoutServiceImpl;

public class MemberController implements Controller {
	Service service;
	Hashtable<String, Service> map = new Hashtable<String, Service>();
	{
		map.put("/join", new JoinServiceImpl());
		map.put("/list", new ListServiceImpl());
		map.put("/login", new LoginServiceImpl());
		map.put("/logout", new LogoutServiceImpl());
		map.put("/detail", new DetailServiceImpl());
		map.put("/findid", new FindIDServiceImpl());
		map.put("/modify", new ModifyServiceImpl());
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		service = map.get(req.getAttribute("serviceKey"));
		return service.request(req, resp);
	}
}
