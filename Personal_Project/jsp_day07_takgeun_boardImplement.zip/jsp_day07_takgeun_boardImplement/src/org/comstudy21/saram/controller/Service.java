package org.comstudy21.saram.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.controller.ViewResolver;
import org.comstudy21.saram.model.SaramDao;

public interface Service extends Controller {
	
}
