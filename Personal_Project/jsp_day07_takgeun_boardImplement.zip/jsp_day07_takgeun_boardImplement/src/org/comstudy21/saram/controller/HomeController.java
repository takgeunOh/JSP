package org.comstudy21.saram.controller;

import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.home.service.DeleteServiceImpl;
import org.comstudy21.saram.home.service.DetailServiceImpl;
import org.comstudy21.saram.home.service.InputServiceImpl;
import org.comstudy21.saram.home.service.ListServiceImpl;
import org.comstudy21.saram.home.service.ModifyServiceImpl;

public class HomeController implements Controller {
	Service service;
	Hashtable<String, Service> mapping = new Hashtable<String, Service>();
	{
		mapping.put("/list", new ListServiceImpl());
		mapping.put("/input", new InputServiceImpl());
		mapping.put("/modify", new ModifyServiceImpl());
		mapping.put("/delete", new DeleteServiceImpl());
		mapping.put("/detail", new DetailServiceImpl());
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		String key = (String)req.getAttribute("serviceKey");
		service = mapping.get(key);
		return service.request(req, resp);
	}

}
