package org.comstudy21.saram.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.gallery.service.GalleryListServiceImpl;

public class GalleryController implements Controller {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		
		return new GalleryListServiceImpl().request(req, resp);
	}
	
}
