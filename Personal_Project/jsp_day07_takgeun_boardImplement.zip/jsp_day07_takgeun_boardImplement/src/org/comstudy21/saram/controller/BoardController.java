package org.comstudy21.saram.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.board.service.BoardDeleteServiceImpl;
import org.comstudy21.saram.board.service.BoardDetailServiceImpl;
import org.comstudy21.saram.board.service.BoardInsertServiceImpl;
import org.comstudy21.saram.board.service.BoardListServiceImpl;
import org.comstudy21.saram.board.service.BoardSearchServiceImpl;
import org.comstudy21.saram.board.service.BoardUpdateServiceImpl;

public class BoardController implements Controller {
	
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		// 게시글 조회는 get 방식으로 진행할 것.
		// return new ModelAndView("bbs/list", false);
		
		System.out.println("BoardController serviceKey : " + req.getAttribute("serviceKey"));
		if(req.getAttribute("serviceKey").equals("/list")) {
			return new BoardListServiceImpl().request(req, resp);
		} else if (req.getAttribute("serviceKey").equals("/search")) {
			return new BoardSearchServiceImpl().request(req, resp);
		} else if (req.getAttribute("serviceKey").equals("/detail")) {
			return new BoardDetailServiceImpl().request(req, resp);
		} else if (req.getAttribute("serviceKey").equals("/insert")) {
			return new BoardInsertServiceImpl().request(req, resp);
		} else if (req.getAttribute("serviceKey").equals("/update")) {
			return new BoardUpdateServiceImpl().request(req, resp);
		} else if (req.getAttribute("serviceKey").equals("/delete")) {
			return new BoardDeleteServiceImpl().request(req, resp);
		}
		
		return null;
	}

}
