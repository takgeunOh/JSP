package org.comstudy21.saram.home.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.SaramDto;

public class DeleteServiceImpl implements Service {
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String strNo = req.getParameter("no");
		System.out.println("strNo => " + strNo);
		
		saramDao.delete(new SaramDto(Integer.parseInt(strNo), "", "", ""));
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}
	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		ModelAndView modelAndView = new ModelAndView("list.saram", true);
		if("GET".equals(req.getMethod())) {
			try {
				doGet(req, resp);
			} catch (ServletException | IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				doPost(req, resp);
			} catch (ServletException | IOException e) {
				e.printStackTrace();
			}
		}
		return modelAndView;
	}
}
