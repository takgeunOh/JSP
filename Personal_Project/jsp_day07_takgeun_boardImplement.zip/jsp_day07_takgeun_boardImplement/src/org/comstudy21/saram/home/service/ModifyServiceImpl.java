package org.comstudy21.saram.home.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.SaramDto;

public class ModifyServiceImpl implements Service {
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String noStr = req.getParameter("no");
		System.out.println("no => " + noStr);
		
		// dao에서 검색
		SaramDto saramDto = saramDao.selectByNo(Integer.parseInt(noStr));
		req.setAttribute("saramDto", saramDto);
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		System.out.println("POST 요청 시 호출");
		// 전달된 파라미터를 받아서 처리 하자.
		String no = req.getParameter("no");
		String name = req.getParameter("name");
		String phone = req.getParameter("phone");
		String email = req.getParameter("email");
		
		SaramDto dto = new SaramDto(Integer.parseInt(no), name, phone, email);
		
		saramDao.update(dto);
	}

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		ModelAndView modelAndView = new ModelAndView("list.saram", true);
		if("GET".equals(req.getMethod())) {
			try {
				doGet(req, resp);
			} catch (ServletException | IOException e) {
				e.printStackTrace();
			}
			modelAndView = new ModelAndView("home/saram_modify");
		} else {
			try {
				doPost(req, resp);
			} catch (ServletException | IOException e) {
				e.printStackTrace();
			}
		}
		return modelAndView;
	}
}
