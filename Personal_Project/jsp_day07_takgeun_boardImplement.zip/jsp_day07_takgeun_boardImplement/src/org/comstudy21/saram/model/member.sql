drop table member;

create table member (
no number primary key,
id varchar2(30) not null,
password varchar(50) not null,
name varchar2(20),
email varchar2(50)
);

CREATE SEQUENCE mem_seq start with 1 increment by 1;

insert into member 
values(mem_seq.nextval, 'user01', '1234', 'kim', 'user01@comstudy21.org');
insert into member 
values(mem_seq.nextval, 'user02', '1234', 'kim2', 'user02@comstudy21.org');

commit

select * from member;

delete from member where no=3;
commit