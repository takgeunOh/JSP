package org.comstudy21.saram.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.comstudy21.saram.dbcp.JdbcUtil;

public class MemberDao {

	final String SQL_INSERT = "insert into MEMBER values(mem_seq.nextval, ?, ?, ?, ?)";
	final String SQL_SELECT_ALL = "SELECT * FROM MEMBER ORDER BY NO DESC";
	final String SQL_SELECT_NO = "SELECT * FROM MEMBER WHERE NO=?";
	final String SQL_SELECT_ID = "SELECT * FROM MEMBER WHERE ID=?";
	final String SQL_UPDATE = "UPDATE MEMBER SET NAME=?, EMAIL=? WHERE NO=?";
	final String SQL_DELETE = "DELETE FROM MEMBER WHERE NO=?";
	
	final String SQL_LOGIN = "SELECT * FROM MEMBER WHERE ID=? AND PASSWORD=?";
	final String SQL_FIND_ID = "SELECT ID FROM MEMBER WHERE ID=?";

	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;
	
	public MemberDto login(MemberDto dto) {
		MemberDto member = null;
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_LOGIN);
			stmt.setString(1, dto.getId());
			stmt.setString(2, dto.getPassword());
			rs = stmt.executeQuery();
			if (rs.next()) {
				int no = rs.getInt("no");
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String email = rs.getString("email");
				member = new MemberDto(no, id, password, name, email);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}

		return member; // null이면 로그인 실패
	}
	
	public boolean findById(MemberDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_FIND_ID);
			stmt.setString(1, dto.getId());
			rs = stmt.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
		
		return false;
	}

	public void insert(MemberDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_INSERT);
			stmt.setString(1, dto.getId());
			stmt.setString(2, dto.getPassword());
			stmt.setString(3, dto.getName());
			stmt.setString(4, dto.getEmail());
			int cnt = stmt.executeUpdate();
			if (cnt > 0) {
				conn.commit();
			} else {
				conn.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
	}

	public List<MemberDto> selectAll() {
		ArrayList<MemberDto> list = new ArrayList<MemberDto>();
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_ALL);
			rs = stmt.executeQuery();
			while (rs.next()) {
				int no = rs.getInt("no");
				String id = rs.getString("id");
				String password = rs.getNString("password");
				String name = rs.getNString("name");
				String email = rs.getNString("email");
				list.add(new MemberDto(no, id, password, name, email));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
		return list;
	}

	public void update(MemberDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_UPDATE);
			stmt.setString(1, dto.getName());
			stmt.setString(2, dto.getEmail());
			stmt.setInt(3, dto.getNo());
			int cnt = stmt.executeUpdate();
			if (cnt > 0) {
				conn.commit();
			} else {
				conn.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
	}

	public void delete(MemberDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_DELETE);
			stmt.setInt(1, dto.getNo());
			int cnt = stmt.executeUpdate();
			if (cnt > 0) {
				conn.commit();
			} else {
				conn.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}
	}
	public MemberDto selectByName(MemberDto dto) {
		MemberDto member = null;
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_ID);
			stmt.setString(1, dto.getId());
			rs = stmt.executeQuery();
			if (rs.next()) {
				int no = rs.getInt("no");
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String email = rs.getString("email");
				member = new MemberDto(no, id, password, name, email);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}

		return member;
	}

	public MemberDto selectByNo(MemberDto dto) {
		MemberDto member = null;
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_NO);
			stmt.setInt(1, dto.getNo());
			rs = stmt.executeQuery();
			if (rs.next()) {
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String email = rs.getString("email");
				member = new MemberDto(dto.getNo(), id, password, name, email);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}

		return member;
	}

	public MemberDto selectByNo(int no) {
		MemberDto member = null;
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_NO);
			stmt.setInt(1, no);
			rs = stmt.executeQuery();
			if (rs.next()) {
				String id = rs.getString("id");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String email = rs.getString("email");
				member = new MemberDto(no, id, password, name, email);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(conn, stmt, rs);
		}

		return member;
	}
}
