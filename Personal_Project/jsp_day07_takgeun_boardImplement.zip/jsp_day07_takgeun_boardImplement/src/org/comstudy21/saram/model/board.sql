drop table board;

create table board(
   num number(10) primary key,
   author varchar2(100) not null,
   email varchar2(200),
   title varchar2(500),
   content varchar2(4000),
   password varchar2(50) not null,
   writeday date default(sysdate),
   readcnt number(10) default(0),
   rep_root number(10) default(0),
   rep_step number(10) default(0),
   rep_indent number(10) default(0)
);

select * from tab;

select * from board;

create sequence board_seq start with 1 increment by 1;

insert into board(num, author, email, title, content, password)
values(board_seq.nextval, 'test', 'test@test.com', 'test', 'test', '1111');


