package org.comstudy21.saram.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.comstudy21.saram.dbcp.JdbcUtil;

public class BoardDao {
	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;

	String SQL_SELECT = "SELECT * FROM BOARD ORDER BY NUM DESC";
	String SQL_SEARCH_TITLE = "SELECT * FROM BOARD WHERE TITLE LIKE '%'||?||'%' or AUTHOR LIKE '%'||?||'%' or CONTENT LIKE '%'||?||'%' ORDER BY NUM DESC";
	String SQL_SELECT_ONE = "SELECT * FROM BOARD WHERE NUM=?";
	String SQL_INSERT = "insert into BOARD (num, author, email, title, content, password, writeday) values(board_seq.nextval, ?,?,?,?,?,sysdate)";
	String SQL_UPDATE = "UPDATE BOARD SET TITLE=?, CONTENT=? WHERE NUM=?";
	String SQL_DELETE = "DELETE FROM BOARD WHERE NUM=?";
	String SQL_UPDATE_READCOUNT = "update board set readcnt=? where num=?";

	public ArrayList<BoardDto> selectAll() {
		
		ArrayList<BoardDto> list = new ArrayList<BoardDto>();
		
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				int num = rs.getInt("num");
				String author = rs.getString("author");
				String email = rs.getString("email");
				String title = rs.getString("title");
				String content = rs.getString("content");
				String password = rs.getString("password");
				String writeday = rs.getString("writeday");
				int readcnt = rs.getInt("readcnt");
				int rep_root = rs.getInt("rep_root");
				int rep_step = rs.getInt("rep_step");
				int rep_indent = rs.getInt("rep_indent");
				
				BoardDto boardDto = new BoardDto(num, author, email, title, content, password, writeday, readcnt, rep_root, rep_step, rep_indent);
				
				list.add(boardDto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
		
		return list;
	}

	public BoardDto selectOne(BoardDto dto) {
		return null;
	}

	public BoardDto selectOne(int num) {
		BoardDto boardDto = new BoardDto();
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_ONE);
			stmt.setInt(1, num);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				int rsNum = rs.getInt("num");
				String author = rs.getString("author");
				String email = rs.getString("email");
				String title = rs.getString("title");
				String content = rs.getString("content");
				String password = rs.getString("password");
				String writeday = rs.getString("writeday");
				int readcnt = rs.getInt("readcnt");
				int rep_root = rs.getInt("rep_root");
				int rep_step = rs.getInt("rep_step");
				int rep_indent = rs.getInt("rep_indent");
				
				boardDto = new BoardDto(rsNum, author, email, title, content, password, writeday, readcnt, rep_root, rep_step, rep_indent);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
		
		return boardDto;
	}

	void update(BoardDto dto) {

	}

	public void delete(BoardDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_DELETE);
			stmt.setInt(1, dto.getNum());
			int cnt=stmt.executeUpdate();
			
			if(cnt>0)
				conn.commit();
			else
				conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}

	public ArrayList<BoardDto> search(String searchText) {
		// title, author, content 순으로 물음표에 데이터가 들어갈 것.
		ArrayList<BoardDto> list = new ArrayList<BoardDto>();
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SEARCH_TITLE);
			stmt.setString(1, searchText);
			stmt.setString(2, searchText);
			stmt.setString(3, searchText);
			
			rs = stmt.executeQuery();
			while(rs.next()) {
				int num = rs.getInt("num");
				String author = rs.getString("author");
				String email = rs.getString("email");
				String title = rs.getString("title");
				String content = rs.getString("content");
				String password = rs.getString("password");
				String writeday = rs.getString("writeday");
				int readcnt = rs.getInt("readcnt");
				int rep_root = rs.getInt("rep_root");
				int rep_step = rs.getInt("rep_step");
				int rep_indent = rs.getInt("rep_indent");
				
				BoardDto boardDto = new BoardDto(num, author, email, title, content, password, writeday, readcnt, rep_root, rep_step, rep_indent);
				
				list.add(boardDto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
		
		return list;
	}

	public void insert(BoardDto dto) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_INSERT);
			stmt.setString(1, dto.getAuthor());
			stmt.setString(2, dto.getEmail());
			stmt.setString(3, dto.getTitle());
			stmt.setString(4, dto.getContent());
			stmt.setString(5, dto.getPassword());
			
			int cnt = stmt.executeUpdate();
			
			if (cnt>0)
				conn.commit();
			else
				conn.rollback();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}
	
	public void update(String modifyTitle, String modifyContent, int modifyNum) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_UPDATE);
			stmt.setString(1, modifyTitle);
			stmt.setString(2, modifyContent);
			stmt.setInt(3, modifyNum);
			
			int cnt = stmt.executeUpdate();
			
			if(cnt>0)
				conn.commit();
			else
				conn.rollback();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}
	
	
	public int ExtractReadCount(int num) {
		// 먼저 번호로 찾고
		// 해당 번호의 조회수를 추출한 다음
		// 그 번호인 애한테 추출한 조회수 + 1 해주기
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_SELECT_ONE);
			stmt.setInt(1, num);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				int saveReadCount = rs.getInt("readcnt");
				return saveReadCount;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
		
		return 0;
	}
	
	public void readCountUpdate(int saveReadCount, int num) {
		conn = JdbcUtil.getConnection();
		try {
			stmt = conn.prepareStatement(SQL_UPDATE_READCOUNT);
			stmt.setInt(1, saveReadCount+1);
			stmt.setInt(2, num);
			int cnt = stmt.executeUpdate();
			
			if(cnt>0)
				conn.commit();
			else
				conn.rollback();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		JdbcUtil.close(conn, stmt, rs);
	}
}
