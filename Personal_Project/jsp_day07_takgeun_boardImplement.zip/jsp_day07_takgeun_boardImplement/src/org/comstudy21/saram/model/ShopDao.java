package org.comstudy21.saram.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.comstudy21.saram.dbcp.JdbcUtil;

import jdk.jshell.execution.JdiExecutionControlProvider;

public class ShopDao {
	Connection conn;
	PreparedStatement stmt;
	ResultSet rs;

	static List<ShopDto> list = new ArrayList<ShopDto>();
	static {
		list.add(new ShopDto(10, "냉장고", 400, "LG", 1));
		list.add(new ShopDto(11, "세탁기", 200, "SAMSUNG", 1));
		list.add(new ShopDto(21, "청소기", 120, "다이슨", 1));
		list.add(new ShopDto(32, "테레비", 300, "노브랜드", 1));
		list.add(new ShopDto(44, "핸드폰", 120, "애플", 1));
		list.add(new ShopDto(55, "건조기", 70, "LG", 1));
		list.add(new ShopDto(61, "레인지", 50, "LG", 1));
		list.add(new ShopDto(71, "에어콘", 200, "위니아", 1));
		list.add(new ShopDto(81, "리모콘", 10, "LG", 1));
		list.add(new ShopDto(90, "선풍기", 40, "신일", 1));
	}

	public void insert(ShopDto dto) {

	}

	public List<ShopDto> selectAll() {

		return list;
	}

	public void update(ShopDto dto) {

	}
	
	public void updateEa() {
		
	}

	public void delete(ShopDto dto) {
		int idx = list.indexOf(dto);
		if(idx != -1) {
			list.remove(idx);
			System.out.println(list);
		}
	}

	public ShopDto selectByName(ShopDto dto) {

		return null;
	}

	public ShopDto selectByNo(ShopDto dto) {
		int idx = list.indexOf(dto);
		if(idx != -1 ) {
			return list.get(idx);
		}
		return null;
	}

	public ShopDto selectByNo(int no) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i).getNo() == no) {
				return (ShopDto) list.get(i).clone();
			}
		}
		return null;
	}
}
