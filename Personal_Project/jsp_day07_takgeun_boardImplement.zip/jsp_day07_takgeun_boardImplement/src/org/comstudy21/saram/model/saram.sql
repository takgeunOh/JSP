create user comstudy21 identified by comstudy21 account unlock;

grant dba to comstudy21;

conn comstudy21/comstudy21;

create table saram (
no number,
name varchar(20),
phone varchar(15),
email varchar(50)
);

insert into saram values(1, 'HONG', '010-1111-1111', 'hong@comstudy21.com');
insert into saram values(2, 'USER01', '010-1111-2222', 'user01@comstudy21.com');