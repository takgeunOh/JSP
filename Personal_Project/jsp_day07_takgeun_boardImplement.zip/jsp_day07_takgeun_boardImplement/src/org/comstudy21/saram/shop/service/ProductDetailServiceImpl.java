package org.comstudy21.saram.shop.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.ShopDto;

public class ProductDetailServiceImpl implements Service {

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		int no = Integer.parseInt(req.getParameter("no"));
		System.out.println("ProductDetailServiceImpl");
		
		ShopDto shopDto = shopDao.selectByNo(no);
		System.out.println(shopDto);
		req.setAttribute("shopDto", shopDto);
		
		return new ModelAndView("shop/detail", false);
	}

}
