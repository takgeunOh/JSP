package org.comstudy21.saram.shop.service;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.SaramDto;
import org.comstudy21.saram.model.ShopDao;
import org.comstudy21.saram.model.ShopDto;

public class ShopListServiceImpl implements Service {
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<ShopDto> productList = (ArrayList<ShopDto>)shopDao.selectAll();
		req.setAttribute("productList", productList);
	}

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		try {
			doGet(req, resp);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
		return new ModelAndView("shop/list", false);
	}

}
