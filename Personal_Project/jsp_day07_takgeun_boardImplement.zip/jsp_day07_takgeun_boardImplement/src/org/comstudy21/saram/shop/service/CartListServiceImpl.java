package org.comstudy21.saram.shop.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.comstudy21.controller.ModelAndView;
import org.comstudy21.saram.controller.Service;
import org.comstudy21.saram.model.ShopDto;

public class CartListServiceImpl implements Service {
	private HttpSession session;

	@Override
	public ModelAndView request(HttpServletRequest req, HttpServletResponse resp) {
		session = req.getSession();
		String command = req.getParameter("cmd");
		int no = req.getParameter("no")!=null ? Integer.parseInt(req.getParameter("no")): -1;
		System.out.println(command);
		if("GET".equals(req.getMethod())) {
			System.out.println("GET >>>>>> ");
			if("delete".equals(command)) {
				System.out.println("카트 목록 보기 >> no : " + no);
				System.out.println("command => " + command);
				ArrayList<ShopDto> cartList = (ArrayList<ShopDto>)session.getAttribute("cartList");
				for(int i=0; i<cartList.size(); i++) {
					if(cartList.get(i).getNo() == no) {
						cartList.remove(i);
					}
				}
				return new ModelAndView("cart.saram", true);
			}
		} else if("POST".equals(req.getMethod())) {
			System.out.println("POST >>>>>> ");
			ShopDto dto = shopDao.selectByNo(no);
			
			int ea = 0;
			if(req.getParameter("ea")!=null)
				ea = Integer.parseInt(req.getParameter("ea"));
			
			ArrayList<ShopDto> cartList = null;
			
			if(session.getAttribute("cartList") == null) {
				// 최초로 만든 cartList
				cartList = new ArrayList<ShopDto>();
				session.setAttribute("cartList", cartList);
			} else {
				cartList = (ArrayList<ShopDto>)session.getAttribute("cartList");
			}
				
			int findIndex = cartList.indexOf(dto);
			if(findIndex == -1) {
				dto.setEa(ea);
				cartList.add(dto);
				return new ModelAndView("cart.saram", true);
			} else {
				ShopDto findDto = cartList.get(findIndex);
				findDto.setEa(findDto.getEa()+ea);
				
				return new ModelAndView("cart.saram", true);
			}
		}
		
		return new ModelAndView("shop/cart", false);
	}

}
