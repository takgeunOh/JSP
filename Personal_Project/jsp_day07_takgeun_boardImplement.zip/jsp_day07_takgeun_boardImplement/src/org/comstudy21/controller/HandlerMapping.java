package org.comstudy21.controller;

import java.util.Hashtable;

import org.comstudy21.saram.controller.BoardController;
import org.comstudy21.saram.controller.Controller;
import org.comstudy21.saram.controller.GalleryController;
import org.comstudy21.saram.controller.HomeController;
import org.comstudy21.saram.controller.MemberController;
import org.comstudy21.saram.controller.ShopController;

public class HandlerMapping {
	Hashtable<String, Controller> map = new Hashtable<String, Controller>();
	public HandlerMapping() {
		map.put("/home", new HomeController());
		map.put("/bbs", new BoardController());
		map.put("/shop", new ShopController());
		map.put("/member", new MemberController());
		map.put("/gallery", new GalleryController());
	}

	public Controller getController(String path) {
		return map.get(path);
	}

}
