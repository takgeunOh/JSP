package org.comstudy21.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.comstudy21.saram.controller.Controller;
import org.comstudy21.saram.controller.Service;

public class DispatcherServlet extends HttpServlet {
	private HandlerMapping hadlerMapping = new HandlerMapping();
	private ViewResolver viewResolver = new ViewResolver();
	private void process(HttpServletRequest req, HttpServletResponse resp) {
		// path를 만들어 준다.
		// path.substring();
		// 하위 Controller를 분기 해 준다.
		// ... /home/list.saram
		String method = req.getMethod();
		String ctxPath = req.getContextPath();
		String reqUri = req.getRequestURI();
		int beginIndex = ctxPath.length();
		int endIndex = reqUri.indexOf(".");
		
		
		String path = reqUri.substring(beginIndex, endIndex);
		System.out.println("Dispatcher ctxPath : " + ctxPath);
		System.out.println("Dispatcher reqUri : " + reqUri);
		System.out.println("Dispatcher path : " + path);
		
		if(path.equals("/search"))
			path = "/bbs" + path;
		
		System.out.println("Dispatcher changePath : " + path);
		
		req.setAttribute("serviceKey", path.substring(path.indexOf("/", 1)));

		System.out.println("Dispatcher serviceKey : " + req.getAttribute("serviceKey"));
		System.out.println("Dispatcher method : " + method);
		path = path.substring(0, path.indexOf("/", 1));

		Controller controller = hadlerMapping.getController(path);
		if(controller != null) {
			ModelAndView modelAndView = controller.request(req, resp);
			if(modelAndView != null) {
				viewResolver.forward(req, resp, modelAndView);
			} else {
				System.out.println(">>>> modelAndView가 null입니다.");
			}
		} else {
			System.out.println(">>>> controller가 null입니다.");
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req, resp);
	}
}
